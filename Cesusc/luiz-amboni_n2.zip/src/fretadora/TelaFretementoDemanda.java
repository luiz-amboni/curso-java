package fretadora;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

public abstract class TelaFretementoDemanda {

    public static FreteDemanda ledadosFreteDemanda(ControleMercadoria controleMercadoria) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n Cadastro frete Regular \n");
        FreteDemanda freteDemanda = new FreteDemanda();
        Mercadoria mercadoria = ControleFrete.SelecionarMercadoria(controleMercadoria);
        freteDemanda.setMercadoria(mercadoria);
        System.out.println("Data Coleta:  dd/mm/yyyy HH:MM");
        String dataColeta = scanner.nextLine();
        String[] datahora = dataColeta.split(" ");
        String[] data = datahora[0].split("/");
        String[] hora = datahora[1].split(":");
        LocalDateTime dataread = LocalDateTime.of(Integer.valueOf(data[2]),Integer.valueOf(data[1]),Integer.valueOf(data[0]),Integer.valueOf(hora[0]),Integer.valueOf(hora[1]));
        System.out.println("Cidade Origem: ");
        freteDemanda.setCidadeOrigem(scanner.nextLine());
        System.out.println("Cidade de Destino: ");
        freteDemanda.setCidadeDestino(scanner.nextLine());
        System.out.println("Distância Km: ");
        freteDemanda.setDistanciaKm(scanner.nextFloat());
        freteDemanda.calculaValorFrete();
        return freteDemanda;
    }

    public static void listarFretes(ArrayList<FreteDemanda> listaFreteDemanda) {
        System.out.println("\nListas Fretes Por Demanda\n");
        for (FreteDemanda frete : listaFreteDemanda) {

            System.out.println("\nCódigo: " + frete.getCodigo());
            System.out.println("Data de coleta: " + frete.getDataColeta());
            System.out.println("Cidade Origem: " + frete.getCidadeOrigem());
            System.out.println("Cidade de Destino: " + frete.getCidadeDestino());
            System.out.println("Distência Km: " + frete.getDistanciaKm());
            System.out.println("Valor frete: R$" + frete.calculaValorFrete());
            System.out.println("Mercadoria: " + frete.getMercadoria().toString());

        }
    }
}

package fretadora;

import java.time.LocalDateTime;

public class FreteDemanda extends Frete {

    public LocalDateTime dataColeta;

    public FreteDemanda(Mercadoria mercadoria, String cidadeOrigem, String cidadeDestino, Float distanciaKm, Double valorFrete, LocalDateTime dataColeta) {
        super(mercadoria, cidadeOrigem, cidadeDestino, distanciaKm, valorFrete);
        this.dataColeta = dataColeta;
    }

    public FreteDemanda() {
        super();
    }

    @Override
    public String toString() {
        return "FreteDemanda{" +
                "dataColeta=" + dataColeta +
                super.toString()+
                '}';
    }

    public LocalDateTime getDataColeta() {
        return dataColeta;
    }

    public void setDataColeta(LocalDateTime dataColeta) {
        this.dataColeta = dataColeta;
    }

    @Override
    public Double calculaValorFrete() {
        Double calcvalorfretedemanda = (300 + 0.6 * getDistanciaKm());
        this.setValorFrete(calcvalorfretedemanda);
        return calcvalorfretedemanda;
    }
}

package fretadora;

import java.util.ArrayList;
import java.util.Scanner;

public abstract class TelaEmbalagem {

    public static Embalagem leDadosEmbalagem(){
        Scanner scanner = new Scanner(System.in);

        Embalagem embalagem = new Embalagem();
        System.out.println("Cadastro Embalagem\n");
        System.out.println("Material da Embalagem: ");
        embalagem.setMaterialEmbalagem(scanner.nextLine());
        System.out.println("Quantidade de embalagens: ");
        embalagem.setQuantidadeEmbalem(scanner.nextFloat());
        System.out.println("Descrição: ");
        scanner.nextLine();
        embalagem.setDescricao(scanner.nextLine());
        System.out.println("Tipo: ");
        embalagem.setTipo(scanner.nextLine());
        System.out.println("Peso: ");
        embalagem.setPeso(scanner.nextFloat());
        System.out.println("Número nota fiscal: ");
        scanner.nextLine();
        embalagem.setNumeroNotaFiscal(scanner.nextLine());
        return embalagem;
    }

    public static void listaEmbalagens(ArrayList<Mercadoria> listaMercadorias){
        System.out.println("\nLista Embalagens\n");
        for (Mercadoria mercadoria: listaMercadorias) {
            if (mercadoria instanceof Embalagem) {
                //type cast
                Embalagem mercemb = (Embalagem) mercadoria;

                System.out.println("\nCódigo " + mercemb.getCodigo());
                System.out.println("Material da Embalagem: " + mercemb.getMaterialEmbalagem());
                System.out.println("Quantidade de Embalagens: " + mercemb.getQuantidadeEmbalem());
                System.out.println("Descrição: " + mercemb.getDescricao());
                System.out.println("Tipo: " + mercemb.getTipo());
                System.out.println("Peso: " + mercemb.getPeso());
                System.out.println("Número nota fiscal: " + mercemb.getNumeroNotaFiscal());
            }
        }
    }
}

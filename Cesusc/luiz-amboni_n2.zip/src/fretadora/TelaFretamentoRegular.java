package fretadora;

import java.util.ArrayList;
import java.util.Scanner;

public abstract class TelaFretamentoRegular {

    public static FreteRegular leDadosFreteRegular(ControleMercadoria controleMercadoria) {
        Scanner scanner = new Scanner(System.in);
        FreteRegular freteRegular = new FreteRegular();
        Mercadoria mercadoria = ControleFrete.SelecionarMercadoria(controleMercadoria);
        freteRegular.setMercadoria(mercadoria);
        System.out.println("\n Cadastro frete Regular \n");
        System.out.println("Frequência (Apenas números): ");
        freteRegular.setFrequencia(scanner.nextFloat());
        System.out.println("Unidade de frequência: ");
        scanner.nextLine();
        freteRegular.setUnidadeFrequencia(scanner.nextLine());
        System.out.println("Quantidade de operações: ");
        freteRegular.setQuantidadeOperacoes(scanner.nextInt());
        System.out.println("Cidade Origem: ");
        scanner.nextLine();
        freteRegular.setCidadeOrigem(scanner.nextLine());
        System.out.println("Cidade de Destino: ");
        freteRegular.setCidadeDestino(scanner.nextLine());
        System.out.println("Distência Km: ");
        freteRegular.setDistanciaKm(scanner.nextFloat());
        freteRegular.calculaValorFrete();
        return freteRegular;
    }

    public static void listarFretes(ArrayList<FreteRegular> listaFretesRegular) {
        System.out.println("\nListas Fretes Regulares\n");
        for (FreteRegular frete : listaFretesRegular) {
            System.out.println("\nCódigo: " + frete.getCodigo());
            System.out.println("Frequência: " + frete.getFrequencia());
            System.out.println("Unidade de frequência: " + frete.getUnidadeFrequencia());
            System.out.println("Quantidade de operações: " + frete.getQuantidadeOperacoes());
            System.out.println("Cidade Origem: " + frete.getCidadeOrigem());
            System.out.println("Cidade de Destino: " + frete.getCidadeDestino());
            System.out.println("Distência Km: " + frete.getDistanciaKm());
            System.out.println("Valor frete: R$" + frete.calculaValorFrete());
            System.out.println("Mercadoria: " + frete.getMercadoria().toString());

        }
    }


}

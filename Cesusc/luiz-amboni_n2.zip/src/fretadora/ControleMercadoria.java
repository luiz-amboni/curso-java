package fretadora;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;

public class ControleMercadoria {

    private ArrayList<Mercadoria> listaMercadorias;

    public ControleMercadoria() {
        super();
        listaMercadorias = new ArrayList<>();
    }

    public ArrayList<Mercadoria> getListaMercadorias() {
        return listaMercadorias;
    }

    public void setListaMercadorias(ArrayList<Mercadoria> listaMercadorias) {
        this.listaMercadorias = listaMercadorias;
    }

    public static void listaGeral(ArrayList<Mercadoria> listaMercadorias) {
        System.out.println("\nLista Geral\n");
        for (Mercadoria mercadoria : listaMercadorias) {
            if (mercadoria instanceof Mercadoria) {

                System.out.println("\nCódigo " + mercadoria.getCodigo());
                System.out.println("Descrição: " + mercadoria.getDescricao());
                System.out.println("Número nota fiscal: " + mercadoria.getNumeroNotaFiscal());
            }
        }
    }


    public void leDadosJSON() throws IOException, ClassNotFoundException {
        listaMercadorias.clear();

        //instanciando um parser (interpretador) de arquivos JSON
        //neste caso ele trabalha com JSON j� formatados PrettyPrinting()
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        //crio um vari�vel que e instancio o apontador para ler o arquivo que � passado como
        //parametro
        FileReader filereader = new FileReader("src/listamercadoria.json");

        JsonArray  minhaLista = gson.fromJson(filereader,JsonArray.class);

        for (JsonElement classe : minhaLista){
           listaMercadorias.add(gson.fromJson(classe, (Type) Class.forName(classe.getAsJsonObject().get("classe").getAsString())));
        }

        // libera o leitor do arquivo
        filereader.close();
    }

    public void gravaJSON() {
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            FileWriter filewriter = new FileWriter("src/listamercadoria.json");
            gson.toJson(listaMercadorias,filewriter) ;
            filewriter.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}

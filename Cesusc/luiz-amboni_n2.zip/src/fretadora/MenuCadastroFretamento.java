package fretadora;

import java.io.IOException;
import java.util.Scanner;

public class MenuCadastroFretamento {

    public static void executar(ControleFrete controleFrete, ControleMercadoria controleMercadoria) throws IOException, ClassNotFoundException {
        controleMercadoria.leDadosJSON();
        controleFrete.leDadosJSON(controleMercadoria);
        System.out.println("[1] - Frete Regular");
        System.out.println("[2] - Frete sob Demanda");
        System.out.println("[3] - Lista Frete Regular");
        System.out.println("[4] - Lista Frete sob Demanda");
        int opcaoFretamento = 0;
        Scanner menuFretamento = new Scanner(System.in);
        opcaoFretamento = menuFretamento.nextInt();
        if (opcaoFretamento > 4) {
            System.out.println("Opção inválida!");
        }
        switch (opcaoFretamento) {
            case 1: {
                FreteRegular freteRegular = TelaFretamentoRegular.leDadosFreteRegular(controleMercadoria);
                freteRegular.setCodigo(controleFrete.getListaFreteRegular().size()+1);
                System.out.println("\nFrete Regular Cadastrado!");
                System.out.println(freteRegular.toString());
                controleFrete.getListaFreteRegular().add(freteRegular);
                controleFrete.gravaJSON(controleFrete.getListaFreteRegular(),"listafreteregular.json");
                break;
            }
            case 2: {
                FreteDemanda freteDemanda = TelaFretementoDemanda.ledadosFreteDemanda(controleMercadoria);
                freteDemanda.setCodigo(controleFrete.getListaFreteDemanda().size()+1);
                System.out.println("\nFrete sob Demanda Cadastrado!");
                System.out.println(freteDemanda.toString());
                controleFrete.getListaFreteDemanda().add(freteDemanda);
                controleFrete.gravaJSON(controleFrete.getListaFreteDemanda(),"listafretedemanda.json");
                break;
            }
            case 3: {
                TelaFretamentoRegular.listarFretes(controleFrete.getListaFreteRegular());
                break;
            }
            case 4: {
                TelaFretementoDemanda.listarFretes(controleFrete.getListaFreteDemanda());
                break;
            }
        }
    }
}

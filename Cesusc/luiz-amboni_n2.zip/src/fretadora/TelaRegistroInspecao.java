package fretadora;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Scanner;

public class TelaRegistroInspecao {

    public static void executar(ControleMercadoria controleMercadoria) throws IOException, ClassNotFoundException {
        controleMercadoria.leDadosJSON();
        for (Mercadoria mercadoria : controleMercadoria.getListaMercadorias()) {
            if (mercadoria instanceof MercadoriaAuditada) {
                System.out.println(mercadoria.getCodigo() + " - " + mercadoria.getDescricao());
            }
        }
        System.out.println("Escolha a Mercadoria que deseja inspecionar: ");
        Scanner scanner = new Scanner(System.in);
        int opcao = scanner.nextInt();

        MercadoriaAuditada itemInpecao = (MercadoriaAuditada) controleMercadoria.getListaMercadorias().get(opcao - 1);
        System.out.println("Data de inspeção: dd/mm/yyyy 00:00");
        scanner.nextLine();
        String dataInspecao = scanner.nextLine();
        String[] datahora = dataInspecao.split(" ");
        String[] data = datahora[0].split("/");
        String[] hora = datahora[1].split(":");
        LocalDateTime dataread = LocalDateTime.of(Integer.valueOf(data[2]),Integer.valueOf(data[1]),Integer.valueOf(data[0]),Integer.valueOf(hora[0]),Integer.valueOf(hora[1]));
        System.out.println("Orgão Inspeção: ");
        String orgaoInpecao = scanner.nextLine();
        itemInpecao.inpecionar(dataread,orgaoInpecao);
        controleMercadoria.gravaJSON();
        System.out.println("Inpeção registrada!");

    }
}

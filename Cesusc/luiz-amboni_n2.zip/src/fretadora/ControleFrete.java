package fretadora;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ControleFrete {

    private ArrayList<FreteRegular> listaFreteRegular;

    private ArrayList<FreteDemanda> listaFreteDemanda;

    public ArrayList<FreteDemanda> getListaFreteDemanda() {
        return listaFreteDemanda;
    }

    public ControleFrete() {
        super();
        listaFreteRegular = new ArrayList<>();
        listaFreteDemanda = new ArrayList<>();
    }

    public ArrayList<FreteRegular> getListaFreteRegular() {
        return listaFreteRegular;
    }

    public static Mercadoria SelecionarMercadoria(ControleMercadoria controleMercadoria) {
        Scanner scanner = new Scanner(System.in);
        ControleMercadoria.listaGeral(controleMercadoria.getListaMercadorias());
        System.out.println("\nSelecione uma mercadoria para ser transportada pelo código: " );
        Integer opcaoSelecionada = scanner.nextInt();
        Mercadoria mercadoria = controleMercadoria.getListaMercadorias().get(opcaoSelecionada -1);
        return mercadoria;
    }

    public void setListaFreteRegular(ArrayList<FreteRegular> listaFreteRegular) {
        this.listaFreteRegular = listaFreteRegular;
    }

    public void leDadosJSON(ControleMercadoria controleMercadoria) throws IOException {
        listaFreteRegular.clear();
        listaFreteDemanda.clear();
        Gson gson = new GsonBuilder().setPrettyPrinting().create();

        FileReader filereaderRegular = new FileReader("src/listafreteregular.json");
        FileReader filereaderDemanda = new FileReader("src/listafretedemanda.json");

        TypeToken<ArrayList<FreteRegular>> token1 = new TypeToken<ArrayList<FreteRegular>>() {};
        TypeToken<ArrayList<FreteDemanda>> token2 = new TypeToken<ArrayList<FreteDemanda>>() {};

        ArrayList<FreteRegular> minhaListaFreteRegular = gson.fromJson(filereaderRegular, token1.getType());
        ArrayList<FreteDemanda> minhaListaFreteDemanda = gson.fromJson(filereaderDemanda, token2.getType());

        listaFreteRegular = minhaListaFreteRegular;
        listaFreteDemanda = minhaListaFreteDemanda;

        // libera o leitor do arquivo
        filereaderRegular.close();
        filereaderDemanda.close();

        for (FreteRegular freteRegular: listaFreteRegular) {
            Integer codigoMercadoria = freteRegular.getMercadoria().getCodigo();
            Mercadoria mercadoria = controleMercadoria.getListaMercadorias().get(codigoMercadoria-1);
            freteRegular.setMercadoria(mercadoria);
        }

        for (FreteDemanda freteDemanda: listaFreteDemanda) {
            Integer codigoMercadoria = freteDemanda.getMercadoria().getCodigo();
            Mercadoria mercadoria = controleMercadoria.getListaMercadorias().get(codigoMercadoria-1);
            freteDemanda.setMercadoria(mercadoria);
        }
    }

    public void gravaJSON(ArrayList<? extends Frete> lista, String nomeArquivo) {
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            FileWriter filewriter = new FileWriter(nomeArquivo);
            gson.toJson(lista,filewriter) ;
            filewriter.close();

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}

package fretadora;

public class Mercadoria {

    private Integer codigo;
    private String descricao;
    private String tipo;
    private Float peso;
    private String numeroNotaFiscal;
    private String classe;

    public String getDescricao() {
        return descricao;
    }

    public Mercadoria(String descricao, String tipo, Float peso, String numeroNotaFiscal) {
        this();
        this.descricao = descricao;
        this.tipo = tipo;
        this.peso = peso;
        this.numeroNotaFiscal = numeroNotaFiscal;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public Mercadoria() {

        this.classe = getClass().getName();
    }

    @Override
    public String toString() {
        return
                ", descricao='" + descricao + '\'' +
                ", tipo='" + tipo + '\'' +
                ", peso=" + peso +
                ", numeroNotaFiscal='" + numeroNotaFiscal + '\'' ;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Float getPeso() {
        return peso;
    }

    public void setPeso(Float peso) {
        this.peso = peso;
    }

    public String getNumeroNotaFiscal() {
        return numeroNotaFiscal;
    }

    public void setNumeroNotaFiscal(String numeroNotaFiscal) {
        this.numeroNotaFiscal = numeroNotaFiscal;
    }


}

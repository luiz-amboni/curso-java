package fretadora;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

public abstract class TelaCombustivel {

    public static Combústivel leDadosCombustivel(){
        Scanner scanner = new Scanner(System.in);
        Combústivel combustivel = new Combústivel();
        System.out.println("\nCadastro Combustível\n");
        System.out.println("Tipo de Comcustível: ");
        combustivel.setTipoCombustivel(scanner.nextLine());
        System.out.println("Quantidade de Combustível(l): ");
        combustivel.setQuantidadeCombustivel(scanner.nextFloat());
        System.out.println("Descrição: ");
        scanner.nextLine();
        combustivel.setDescricao(scanner.nextLine());
        System.out.println("Tipo: ");
        combustivel.setTipo(scanner.nextLine());
        System.out.println("Peso: ");
        combustivel.setPeso(scanner.nextFloat());
        System.out.println("Número nota fiscal: ");
        scanner.nextLine();
        combustivel.setNumeroNotaFiscal(scanner.nextLine());
        return combustivel;
    }

    public static void  listaCombustivel(ArrayList<Mercadoria> listaMercadoria) {
        int cont = 0;
        String mensagemInpecaoNRealizada = "Inspeção não realizada.";
        System.out.println("\nLista Combustível\n");
        for (Mercadoria mercadoria : listaMercadoria) {
            cont ++;
            if (mercadoria instanceof Combústivel) {
                Combústivel combus = (Combústivel) mercadoria;

                System.out.println("\nCódigo: " + combus.getCodigo());
                System.out.println("Tipo de Combústivel: " + combus.getTipoCombustivel());
                System.out.println("Quantidade de Combústivel: " + combus.getQuantidadeCombustivel());
                System.out.println("Data de inspeção: " + (combus.getDataInspecao() != null? combus.getDataInspecao(): mensagemInpecaoNRealizada));
                System.out.println("Orgão Inspeção: " + (combus.getOrgaoInspecao() != null? combus.getOrgaoInspecao(): mensagemInpecaoNRealizada));
                System.out.println("Descrição: " + combus.getDescricao());
                System.out.println("Tipo: " + combus.getTipo());
                System.out.println("Peso: " + combus.getPeso());
                System.out.println("Número nota fiscal: " + combus.getNumeroNotaFiscal());
            }
        }
    }
}

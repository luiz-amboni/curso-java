package fretadora;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

public abstract class TelaProdutosPerigosos {

    public static ProdutosPerigosos leDadosProdutosPerigosos(){
        Scanner scanner = new Scanner(System.in);
        ProdutosPerigosos produtosPerigosos = new ProdutosPerigosos();
        System.out.println("\nCadastro Produtos Perigosos\n");
        System.out.println("Nome da mercadoria: ");
        produtosPerigosos.setNomeMercadoria(scanner.nextLine());
        System.out.println("Descrição: ");
        produtosPerigosos.setDescricao(scanner.nextLine());
        System.out.println("Tipo: ");
        produtosPerigosos.setTipo(scanner.nextLine());
        System.out.println("Peso: ");
        produtosPerigosos.setPeso(scanner.nextFloat());
        System.out.println("Número nota fiscal: ");
        scanner.nextLine();
        produtosPerigosos.setNumeroNotaFiscal(scanner.nextLine());
        return produtosPerigosos;
    }

    public static void  listaProdutosPerigosos(ArrayList<Mercadoria> listaMercadoria) {
        int cont = 0;
        String mensagemInpecaoNRealizada = "Inspeção não realizada.";
        System.out.println("\nLista Produtos Perigosos\n");
        for (Mercadoria mercadoria : listaMercadoria) {
            cont ++;
            if (mercadoria instanceof ProdutosPerigosos) {
                ProdutosPerigosos prodper = (ProdutosPerigosos) mercadoria;

                System.out.println("\nCódigo: " + prodper.getCodigo());
                System.out.println("Nome da mercadoria: " + prodper.getNomeMercadoria());
                System.out.println("Data de inspeção: " + (prodper.getDataInspecao() != null? prodper.getDataInspecao(): mensagemInpecaoNRealizada));
                System.out.println("Orgão Inspeção: " + (prodper.getOrgaoInspecao() != null? prodper.getOrgaoInspecao(): mensagemInpecaoNRealizada));
                System.out.println("Descrição: " + prodper.getDescricao());
                System.out.println("Tipo: " + prodper.getTipo());
                System.out.println("Peso: " + prodper.getPeso());
                System.out.println("Número nota fiscal: " + prodper.getNumeroNotaFiscal());
            }
        }
    }
}

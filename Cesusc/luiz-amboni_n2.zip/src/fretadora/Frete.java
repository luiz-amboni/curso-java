package fretadora;

public abstract class Frete {

    private Integer codigo;

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    private Mercadoria mercadoria;
    private String cidadeOrigem;
    private String cidadeDestino;
    private Float distanciaKm;
    private Double valorFrete;


    public void setValorFrete(Double valorFrete) {
        this.valorFrete = valorFrete;
    }

    public Frete(Mercadoria mercadoria, String cidadeOrigem, String cidadeDestino, Float distanciaKm, Double valorFrete) {
        this.mercadoria = mercadoria;
        this.cidadeOrigem = cidadeOrigem;
        this.cidadeDestino = cidadeDestino;
        this.distanciaKm = distanciaKm;
        this.valorFrete = valorFrete;
    }

    public Frete() {
    }

    public Double getValorFrete() {
        return valorFrete;
    }

    @Override
    public String toString() {
        return
                ", mercadoria='" + mercadoria.toString() + '\'' +
                ", cidadeOrigem='" + cidadeOrigem + '\'' +
                ", cidadeDestino='" + cidadeDestino + '\'' +
                ", distanciaKm=" + distanciaKm + '\'' +
                ", valorFrete=" + valorFrete
                ;
    }

    public Mercadoria getMercadoria() {
        return mercadoria;
    }

    public void setMercadoria(Mercadoria mercadoria) {
        this.mercadoria = mercadoria;
    }

    public String getCidadeOrigem() {
        return cidadeOrigem;
    }

    public void setCidadeOrigem(String cidadeOrigem) {
        this.cidadeOrigem = cidadeOrigem;
    }

    public String getCidadeDestino() {
        return cidadeDestino;
    }

    public void setCidadeDestino(String cidadeDestino) {
        this.cidadeDestino = cidadeDestino;
    }

    public Float getDistanciaKm() {
        return distanciaKm;
    }

    public void setDistanciaKm(Float distanciaKm) {
        this.distanciaKm = distanciaKm;
    }

    public abstract Double calculaValorFrete();

}

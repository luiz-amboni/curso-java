package fretadora;

import java.io.IOException;
import java.util.Scanner;

public class Menu {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ControleMercadoria controleMercadoria = new ControleMercadoria();
        ControleFrete controleFrete = new ControleFrete();
        int opcaoMenu = 0;
        do {
            System.out.println("\nMenu Principal \n");
            System.out.println("[1] - Controle de Mercadorias");
            System.out.println("[2] - Controle de Fretamentos");
            System.out.println("[3] - Registrar inspeção de Mercadoria de um fretamento");
            System.out.println("[4] - Sair");
            Scanner leitorMenuPrincipal = new Scanner(System.in);
            opcaoMenu = leitorMenuPrincipal.nextInt();
            if (opcaoMenu > 4 ){
                System.out.println("Opção inválida.");
            }
            switch (opcaoMenu){
                case 1: MenuCadastroMercadoria.executar(controleMercadoria); break;
                case 2: MenuCadastroFretamento.executar(controleFrete, controleMercadoria); break;
                case 3: TelaRegistroInspecao.executar(controleMercadoria); break;
            }
        }while (opcaoMenu != 4);
    }
}


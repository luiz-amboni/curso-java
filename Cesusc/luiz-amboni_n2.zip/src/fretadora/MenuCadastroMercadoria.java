package fretadora;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class MenuCadastroMercadoria {

    public static void executar(ControleMercadoria controleMercadoria) throws IOException, ClassNotFoundException {
        controleMercadoria.leDadosJSON();
        System.out.println("[1] - Cadastro Frutas");
        System.out.println("[2] - Cadastro Embalagens");
        System.out.println("[3] - Cadastro Combustíveis");
        System.out.println("[4] - Cadastro Produtos Perigosos");
        System.out.println("[5] - Lista Frutas");
        System.out.println("[6] - Lista Embalagens");
        System.out.println("[7] - Lista Combustíveis");
        System.out.println("[8] - Lista Produtos Perigosos");
        System.out.println("[9] - Lista De todos as mercadorias.");
        int opcaoMercadoria = 0;
        Scanner menuMercadoria = new Scanner(System.in);
        opcaoMercadoria = menuMercadoria.nextInt();
        if (opcaoMercadoria > 9){
            System.out.println("Opção inválida!");
        }
        switch (opcaoMercadoria){
            case 1: {
                Fruta fruta = TelaFruta.leDadosFruta();
                fruta.setCodigo(controleMercadoria.getListaMercadorias().size()+1);
                System.out.println("\n FRUTA Cadastrada!");
                System.out.println(fruta.toString());
                controleMercadoria.getListaMercadorias().add(fruta);
                controleMercadoria.gravaJSON();
                break;
            }
            case 2: {
                Embalagem embalagem = TelaEmbalagem.leDadosEmbalagem();
                embalagem.setCodigo(controleMercadoria.getListaMercadorias().size()+1);
                System.out.println("\n EMBALAGEM Cadastrada!");
                System.out.println(embalagem.toString());
                controleMercadoria.getListaMercadorias().add(embalagem);
                controleMercadoria.gravaJSON();
                break;
            }
            case 3: {
                Combústivel combústivel = TelaCombustivel.leDadosCombustivel();
                combústivel.setCodigo(controleMercadoria.getListaMercadorias().size()+1);
                System.out.println("\n COMBUSTÍVEL Cadastrado!");
                System.out.println(combústivel.toString());
                controleMercadoria.getListaMercadorias().add(combústivel);
                controleMercadoria.gravaJSON();
                break;
            }
            case 4: {
                ProdutosPerigosos produtosPerigosos = TelaProdutosPerigosos.leDadosProdutosPerigosos();
                produtosPerigosos.setCodigo(controleMercadoria.getListaMercadorias().size()+1);
                System.out.println("\n PRODUTO PERIGOS Cadastrado!");
                System.out.println(produtosPerigosos.toString());
                controleMercadoria.getListaMercadorias().add(produtosPerigosos);
                controleMercadoria.gravaJSON();
                break;
            }
            case 5: {
                TelaFruta.listarFrutas(controleMercadoria.getListaMercadorias());
                break;
            }
            case 6: {
                TelaEmbalagem.listaEmbalagens(controleMercadoria.getListaMercadorias());
                break;
            }
            case 7: {
                TelaCombustivel.listaCombustivel(controleMercadoria.getListaMercadorias());
                break;
            }
            case 8: {
                TelaProdutosPerigosos.listaProdutosPerigosos(controleMercadoria.getListaMercadorias());
                break;
            }
            case 9: {
                ControleMercadoria.listaGeral(controleMercadoria.getListaMercadorias());
                break;
            }
        }
    }
}

package fretadora;

import java.util.ArrayList;
import java.util.Scanner;

public abstract class TelaFruta {

    public static Fruta leDadosFruta(){
        Scanner scanner = new Scanner(System.in);

        Fruta fruta = new Fruta();
        System.out.println("\nCadastro Fruta\n");
        System.out.println("Nome fruta: ");
        fruta.setNomeFruta(scanner.nextLine());
        System.out.println("Preço Kg: ");
        fruta.setPrecoFrutaKg(scanner.nextFloat());
        System.out.println("Descrição: ");
        scanner.nextLine();
        fruta.setDescricao(scanner.nextLine());
        System.out.println("Tipo: ");
        fruta.setTipo(scanner.nextLine());
        System.out.println("Peso: ");
        fruta.setPeso(scanner.nextFloat());
        System.out.println("Número nota fiscal: ");
        scanner.nextLine();
        fruta.setNumeroNotaFiscal(scanner.nextLine());
        return fruta;
    }

    public static void listarFrutas(ArrayList<Mercadoria> listaMercadorias){
        System.out.println("\nLista Frutas\n");
        for (Mercadoria mercadoria: listaMercadorias) {
            if (mercadoria instanceof Fruta) {
                //type cast
                Fruta mercfrut = (Fruta) mercadoria;

                System.out.println("\nCódigo " + mercfrut.getCodigo());
                System.out.println("Nome fruta: " + mercfrut.getNomeFruta());
                System.out.println("Preço Kg: " + mercfrut.getPrecoFrutaKg());
                System.out.println("Descrição: " + mercfrut.getDescricao());
                System.out.println("Tipo: " + mercfrut.getTipo());
                System.out.println("Peso: " + mercfrut.getPeso());
                System.out.println("Número nota fiscal: " + mercfrut.getNumeroNotaFiscal());
            }
        }
    }
}
